# State-Debt-per-Capita
CMPS 165 project
Motion chart of the five US states with the most debt per capita, and the five US states with the least.
