# D3-Courses-Project
A project in D3 to aid in course selection at UCSC.

Currently only displaying the C.S. major as a force collection.

Visualization: https://dailydreaming.github.io/D3-Courses-Project/

Authors:
* Viktor Yankoff
* Lon Blauvelt
* Conner Powell