# WorkplaceDeaths
A data visualization using a data set provided by OSHA
