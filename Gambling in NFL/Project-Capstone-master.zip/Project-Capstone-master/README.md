# Project-Capstone
Capstone Project for CMPS 165 at UCSC
Programmer: Joshua Long

This program takes in data for the 32 teams in the NFL from season csv files that I made to display certain data for each team. Then the 
user is able to place a hypothetical amount of money to bet that amount on one of the teams. Then an algorithm calculates a estimated 
outcome from the game and displays if the user will win or lose money.
