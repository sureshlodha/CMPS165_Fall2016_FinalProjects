There are two files I have in here and the code but I have not really used to them.
They are DeathLocation.tsv and syriaBorderCrossings.tsv.