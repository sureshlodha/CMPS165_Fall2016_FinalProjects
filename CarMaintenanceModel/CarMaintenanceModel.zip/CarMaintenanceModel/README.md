Welcome to our CMPS-165: Data Programming for Visualization Final Project

Title: CarMaintenanceModel

Storyline / Description:
A data visualization that shows when and what should be replaced on your vehicle to keep it maintained using average expected mileage interval changes that would be expected on a car part. The data to help understand this visualization is pulled from articles and answered questions from YourMechanic.com and Edmunds.com. 


Created By:
Brian Nguyen
Haris Hanif


Sources Used:
YourMechanic.com
Edmunds.com

Here is a link to our visualization:
https://bnguye54.github.io/CarMaintenanceModel/
