# BRICS_TimeChart

https://cbui505.github.io/BRICS_TimeChart/

A timechart mapping the GDP, household consumption expenditure, and population of BRICS

GDP mapped to x axis 
household consumption expenditure mapped to y axis
population determines radius of circle

current list of countries will include BRICS in addition to a few core countries such as the USA.
additional features/countries/etc will be worked on and added later on.
