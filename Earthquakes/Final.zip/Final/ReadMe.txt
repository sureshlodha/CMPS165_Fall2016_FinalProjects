READ ME

Final Project: 
Earthquakes since 1900’s 

By Sharad Shrestha
