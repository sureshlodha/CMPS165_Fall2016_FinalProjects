# textile-industry
CMPS 165 - Final Project



Concerning Code Sources:
  - The map style was taken from the following submission demonstrated by Professor Suresh Lodha
    in order to maintain the proper zoom functionality. The respective dependencies have also been directly imported.
    http://sureshlodha.github.io/Projects_Spring16/projects/water/index.html
  - CSS and HTML layouts previously designed by Edgar have been used for the layout
  - 
