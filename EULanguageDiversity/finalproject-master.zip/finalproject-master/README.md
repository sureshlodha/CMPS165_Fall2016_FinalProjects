# finalproject
Final Project Language Landscape by generation geo-map
by Kes, Adam, Alex
