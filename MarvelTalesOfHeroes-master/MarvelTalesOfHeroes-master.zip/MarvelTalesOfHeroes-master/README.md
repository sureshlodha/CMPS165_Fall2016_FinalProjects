# MarvelTalesOfHeroes
An Interactive Timeline Visualization of Marvel's Popular Heroes

CS165 Final MARVEL:TALES OF HEROES

To run our visualization simply download our repository. The Marvel API cannot fulfill HTTPS requests due to the API being in its early stages and only being able to function properly with HTTP requests. Unfortunately this means that we can not have a live version of our visualization on github. Fear not for we are currently looking for another site to post our site to!

If you are curious on instructions on how to properly utilize our visualization view the about the page when running our program.

Sincerely your comic fanatics,

-Edwin Ramirez and Nikola Panayotov
