# ASEAN: Human Development Index
<h3>CMPS 165: Final Project</h3>
<br>
By: Justin Cheon, Mai Linh Ngo, Omar Quereshi 
<br><br>
Done in collaboration with Professor Lodha and Shobhit Maheshwari


<b>Data Visualization:</b> https://justincheon.github.io/HDI
<br/>
<b>Files:</b> https://github.com/justincheon/HDI
<br/>

